var json = {
  "101-1": [
    {
      "question": "猫的骨头有多少个？",
      "option": {
        "A": "206块",
        "B": "230~250块",
        "C": "206~229块",
        "D": "251块"
      },
      "true": "B",
      "type": 1,
      "scores": 10, 
      "checked": false
    },
    {
      "question": "猫怀孕后的妊娠期有多长？",
      "option": {
        "A": "两个月",
        "B": "十个月",
        "C": "五个月",
        "D": "二十个月"
      },
      "true": "A",
      "type": 1,
      "scores": 10,
      "checked": false
    },
    {
      "question": "生活在室内的家猫平均寿命有多长？",
      "option": {
        "A": "10岁",
        "B": "20~25岁",
        "C": "26岁",
        "D": "12~18岁"
      },
      "true": "D",
      "type": 1,
      "scores": 10,
      "checked": false
    },
    {
      "question": "猫标记气味的方式有哪些？",
      "option": {
        "A": "尿液标记",
        "B": "嗅闻标记",
        "C": "脸颊磨蹭",
        "D": "爪子磨蹭"
      },
      "true": ["A","C","D"],
      "type": 2,
      "scores": 10,
      "checked": false
    },
    {
      "question": "猫咪嘴唇上的胡须两侧各有大概多少根？",
      "option": {
        "A": "15根",
        "B": "8根",
        "C": "8~12根"
      },
      "true": "C",
      "type": 1,
      "scores": 10,
      "checked": false
    },
    {
      "question": "比猫咪还能睡的动物是？",
      "option": {
        "A": "蝙蝠",
        "B": "树懒",
        "C": "负鼠",
        "D": "考拉",
        "E": "鼬",
        "F": "蛇"
      },
      "true": ["A", "B", "C", "D"],
      "type": 2,
      "scores": 10,
      "checked": false
    },
    {
      "question": "如今世界上最胖的猫咪有多重？",
      "option": {
        "A": "24.3公斤",
        "B": "26.7公斤",
        "C": "20.03公斤",
        "D": "21.30公斤"
      },
      "true": "D",
      "type": 1,
      "scores": 10,
      "checked": false
    },
    {
      "question": "一只健康的猫咪体温维持在多少度左右？",
      "option": {
        "A": "37.1摄氏度左右",
        "B": "38.9摄氏度左右",
        "C": "36.9摄氏度左右",
        "D": "38.1摄氏度左右"
      },
      "true": "B",
      "type": 1,
      "scores": 10,
      "checked": false
    },
    {
      "question": "猫咪心跳这么快，是爱上我了吗？",
      "option": {
        "A": "是，可以谢主隆恩了",
        "B": "不是，猫咪的心脏本来就每分钟可以跳110-140下，是你自作多情了"
      },
      "true": "B",
      "type": 1,
      "scores": 10,
      "checked": false
    },
    {
      "question": "古代喵星人在哪里的地位最崇高？",
      "option": {
        "A": "古埃及",
        "B": "古罗马",
        "C": "古希腊",
        "D": "古巴比伦",
        "E": "古中国"
      },
      "true": "A",
      "type": 1,
      "scores": 10,
      "checked": false
    },
    {
      "question": "喵星人最早和女巫扯上关系是在什么时候？",
      "option": {
        "A": "13世纪",
        "B": "14世纪",
        "C": "16世纪",
        "D": "15世纪"
      },
      "true": "D",
      "type": 1,
      "scores": 10,
      "checked": false
    },
    {
      "question": "第一部喵星人保护法来自哪个国家？具体在什么时候？",
      "option": {
        "A": "日本 1618",
        "B": "日本 1718",
        "C": "英国 1718",
        "D": "法国 1618"
      },
      "true": "D",
      "type": 1,
      "scores": 10,
      "checked": false
    },
  ]

}

module.exports = {
  questionList: json
}