const envList = [{"envId":"cloud1-8gj9qru5721707d1","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}