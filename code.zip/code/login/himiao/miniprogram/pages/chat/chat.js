  // onLoad:function(options){
  //   wx.cloud.init()
  //   const db = wx.cloud.database();
  //   db.collection('friend').where({
  //     userid:this.data.currentuserid
  //   }).get({
  //     success : res=>{
  //     console.log(res)
  //     console.log(this.data.friendsid)
  //     this.setData({
  //       friendsid:res.data.friendid
  //     })
  //   }
  // })
  // var _ = db.command
  // db.collection('user').where({
  //   id:_.in(this.data.friendsid)
  // }).get({
  //   success:res=>{
  //     this.setData({
  //       friends:res.data
  //     })
  //   }
    
  // }) 
  // }
  // pages/chat/chat.js
Page({
  data:{
    message:[],
    inputMsg:"",
    scrollTop:0
  },
  onLoad:function(options){
    var message = wx.getStorageSync('message');
    var top = message.length * 100;
    this.setData({
      message:message || [],
      scrollTop:top
    })
    
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onUnload:function(){
    wx.setStorageSync('message',this.data.message);
  },
  inputMsg:function(e){
   this.setData({
     inputMsg:e.detail.value
   })
  },
  sendMessage:function(e){
    this.setData({
     inputMsg:e.detail.value.input
   })
    var that = this;
    if(this.data.inputMsg != ""){
      var msg = {type:0,src:"cloud://cloud1-8gj9qru5721707d1.636c-cloud1-8gj9qru5721707d1-1308660109/头像/ic_category_2.jpg",content:this.data.inputMsg};
      //发送信息
      this.setMessage(msg);
      //回复
      wx.request({
        url:"http://www.tuling123.com/openapi/api",
        header:{"Content-type":"application/json"},
        data:{key:"fa7f4d06b0a24b479d29ea0a01672350",info:msg.content},
        success:function(data){
          var reply = {type:1,src:"cloud://cloud1-8gj9qru5721707d1.636c-cloud1-8gj9qru5721707d1-1308660109/头像/ic_category_2.jpg",content:data.data.text};
          that.setMessage(reply);
          that.setData({
            scrollTop:that.data.scrollTop+300
          })
        }
      })
    }
  },
  setMessage:function(msg){
    var msgList = this.data.message;
    msgList.push(msg);
    this.setData({
      message:msgList,
      inputMsg:"",
    })
  }
})