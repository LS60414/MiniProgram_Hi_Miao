// pages/fornum/fornum.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        userid:'',
        currentuser:'',
        show1:false,
        show2:false,
        stores:'',
        store:'',
        cats:'',
        cat:'',
        prescore:0,
        score:1,
        score_text_arr: ['一点心动', '一般心动', '正常心动', '超级心动', '怦然心动'],
        score_text: "",
        score_img_arr: [],
        comment:''
        
    },
    btnmaoka:function(e){
      this.setData({
        show1:!this.data.show1,
        show2:false
      })
  },
  btnstore:function(e){
    var store = e.currentTarget.dataset.store;
    const{cat} = this.data;
    this.setData({
      store:store,
      show1:!this.data.show1,
      show2:false
    })
    console.log(this.data.store)
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('cat').where({
      storeid:this.data.store._id
   }).get({
    success:res=>{
      this.setData({
        cats:res.data,
        cat:res.data[0],
      })
      console.log(cat)
    }
    
  })
  
  },
  btncat:function(e){
    this.setData({
      show2:!this.data.show2,
      show1:false
    })
},
btncats:function(e){
  const{prescore} = this.data;
  var cat = e.currentTarget.dataset.cat;
  this.setData({
    cat:cat,
    show2:!this.data.show2,
    show1:false
})


console.log(this.data.cat)
},

inputcom(e){
  this.setData({
    comment:e.detail.value
  })
  
},
submit :function(e){
  const {comment} = this.data;
  const{prescore} = this.data;
  console.log(this.data.comment);
  console.log(this.data.userid);
  console.log(this.data.cat);
  this.setData({
    prescore:this.data.cat.hot
  })
  wx.cloud.init();
  const db = wx.cloud.database();
  
  db.collection('comment').add({
    data:{
      id2 :-1,
      username : this.data.currentuser.name,
      userimg :this.data.currentuser.img,
      userid:this.data.currentuser._id,
      comment:this.data.comment,
      // id:this.data.lastid+1,
      catid :this.data.cat._id,
      score:this.data.score,
      issecletd :false,
      
    }
  }).then(res=>{
    console.log(res)
  })
  console.log(this.data.currentuser)
  var mycat = this.data.currentuser.mycat
  mycat.push(this.data.cat._id)
  console.log(this.data.userid)
  db.collection('user').where({
    _id:this.data.userid
  }).update({
    data:{
      mycat:mycat, 
    }
  }).then(res=>{
    console.log(res)
  })
  var newscore = this.data.score+this.data.prescore
  console.log(newscore)
  db.collection('cat').where({
    _id:this.data.cat._id
  }).update({
    data:{
      hot:newscore
    }
  }).then(res=>{
    console.log(res)
  })
  this.setData({
    comment:''
  })
  this.onLoad(e);
  wx.showToast({
    title: '添加成功',
  })

  wx.navigateTo({
    url: "/pages/cats/cats?",
  })
  },


//初始化星的数量
_default_score: function (tauch_score = 1) {
  var score_img = [];
  var score = 0;
  for (let i = 0; i < 5; i++) {
    if (i < tauch_score) {
      score_img[i] = "cloud://cloud1-7gavs1qz9e9c4e96.636c-cloud1-7gavs1qz9e9c4e96-1308660109/图标/满心.png"
      score = i;
    } else {
      score_img[i] = "cloud://cloud1-7gavs1qz9e9c4e96.636c-cloud1-7gavs1qz9e9c4e96-1308660109/图标/空心.png"
    }
  }

  this.setData({
    score_img_arr: score_img,
    score_text: this.data.score_text_arr[score]
  });
},

onScore: function (e) {
  var score = e.currentTarget.dataset.score;
  this._default_score(score);
  this.setData({
    score:score
  })
},
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      this._default_score()
       var app = getApp()
      this.setData({
        userid: app.data.userid,
      })
       wx.cloud.init();
       const db = wx.cloud.database();

       var app = getApp()
       this.setData({
         userid:app.data.userid
       })
       
       db.collection('user').where({
         _id:this.data.userid
       }).get({
         success:res=>{
           console.log(res.data)
           this.setData({
             currentuser:res.data[0]
           })
           console.log(this.data.currentuser)
         }
       })

       db.collection('store').get({
         success:res=>{
           this.setData({
             stores:res.data,
             store:res.data[0]
           })
           console.log(this.data.store)
           db.collection('cat').where({
            storeid:this.data.store._id
         }).get({
          success:res=>{
            this.setData({
              cats:res.data,
              cat:res.data[0],
              prescore:res.data[0].hot
            })
            console.log(this.data.cat)
          }
        })
      
         }
       })
       
     
   
  
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})