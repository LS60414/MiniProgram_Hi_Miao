Page({

  /**
   * 页面的初始数据
   */
  data: {
    test:[1,2,3,4,5,6],
    inputvalue :'',
    maxcount:4,
    cattabindex:0,
    index:0,
    news:'',
    newsclass:0,
    currentclass:'',
    newsid:'',
    anew:'',

    
    cattabs:[{id:0,value:"美短",isActive:true
    },{id:1,value:"英短",isActive:false
    },{id:2,value:"布偶",isActive:false
    },{ id:3,value:"暹罗",isActive:false
    },{id:4,value:"田园",isActive:false
    },{id:5,value:"其他",isActive:false
    }],
    tabs:[{id:0,value:"猫咪百科",isActive:true
      // 是否选中
    },{id:1, value:"热点新闻",isActive:false
    },{id:2,value:"生病警讯",isActive:false

    }],
    
 
  },
  btnnews:function(e){
   var anew = e.currentTarget.dataset.anew;
    this.setData({
      anew:anew
    })
    wx.navigateTo({
      url: "/pages/newsdetail/newsdetail?anew="+JSON.stringify(anew),
    })
   },
  handleCatItemTap:function(e){
    let{cattabindex} = e.currentTarget.dataset;
    let {cattabs} = this.data;
    cattabs.forEach((v,i)=>i==cattabindex? v.isActive=true:v.isActive=false);
    this.setData({
      cattabs,
      cattabindex
    })
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('class').where({
      id:this.data.cattabindex
    }).get({
      success : res=>{
        console.log(res.data)
      this.setData({
          currentclass:res.data
          
      })
      console.log(this.data.cattabindex)
      console.log(this.data.currentclass)
    }
    })
    
    // this.setData({
    //   cattabindex
    // })

  },
  handleItemTap :function(e){
    const {index} = e.currentTarget.dataset;
    
    let {tabs} = this.data;//要获取所有的data
    console.log({tabs})
    tabs.forEach((v,i)=>i===index? v.isActive=true:v.isActive=false);

    this.setData({
      //丢回去渲染的作用
      tabs
    })
    wx.cloud.init()
    const db = wx.cloud.database();
    db.collection('news').where({
      newsclass:index
    }).get({
      success : res=>{
      this.setData({
          news:res.data
      })
    }
  })

    },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      wx.cloud.init()
      const db = wx.cloud.database();
      db.collection('news').where({
        newsclass:this.data.newsclass
      }).get({
        success : res=>{
        this.setData({
            news:res.data
        })
      }
    })
    
db.collection('class').where({
  // id:this.data.cattabindex
  id:0
}).get({
  success : res=>{
    console.log(res.data)
  this.setData({
      currentclass:res.data
      
  })
  console.log(this.data.currentclass)
}
})
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})

