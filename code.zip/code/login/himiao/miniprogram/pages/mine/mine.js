// pages/mine/mine.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    currentuserid:'',
    labelsid:'',
    selectlabelid:'',
    currentuser:'',
    labels:'',
    seximg:''
  },
 loadlabels:function(){
  var app = getApp()
  this.setData({
    currentuserid:app.data.userid
  })
  
  
  wx.cloud.init();
  const db = wx.cloud.database();
  db.collection('user').where({
    _id:this.data.currentuserid,
  }).get({
    success:res=>{
      this.setData({
        labelsid:res.data[0].label,
        currentuser:res.data[0]

      })  
      if(res.data[0].sex=="男"){
        db.collection('user').where({
          _id:this.data.currentuserid,
        }).update({
          data:{
            seximg:"cloud://cloud1-7gavs1qz9e9c4e96.636c-cloud1-7gavs1qz9e9c4e96-1308660109/图标/男.png"
          }
        })
        // this.setData({
        //   seximg:"cloud://cloud1-7gavs1qz9e9c4e96.636c-cloud1-7gavs1qz9e9c4e96-1308660109/图标/男1.png"
        // })  
      }else if(res.data[0].sex=="女"){
        db.collection('user').where({
          _id:this.data.currentuserid,
        }).update({
          data:{
            seximg:"cloud://cloud1-7gavs1qz9e9c4e96.636c-cloud1-7gavs1qz9e9c4e96-1308660109/图标/女.png"
          }
        })
        // this.setData({
        //   seximg:"cloud://cloud1-7gavs1qz9e9c4e96.636c-cloud1-7gavs1qz9e9c4e96-1308660109/图标/女1.png"
        // })  
      }
      console.log(this.data)
      const _ = db.command
      console.log(this.data.labelsid)
      db.collection('label').where({
        _id:_.in(this.data.labelsid)
      }).get({
        success:res=>{
          this.setData({
            labels:res.data
          })
        }
      })
    }
  })
  

 },
 modifyinfo: function(){
    wx.navigateTo({
      url: '/pages/modify/modify',
    })
 },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    this.loadlabels();

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   this.loadlabels()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})