// pages/searchcat/searchcat.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        cats:'',
        cat:'',
    },
    btncat:function(e){
        var cat = e.currentTarget.dataset.cat;
        console.log(e.currentTarget.dataset.cat)
        this.setData({
          cat:cat
        })
        wx.navigateTo({
            url: '/pages/catdetail/catdetail?cat='+JSON.stringify(this.data.cat),
          })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.setData({
            cats:JSON.parse(options.searchcats)
        })
        console.log(this.data.cats)
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})