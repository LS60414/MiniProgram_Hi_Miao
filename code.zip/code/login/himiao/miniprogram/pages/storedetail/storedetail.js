// pages/catdetail/catdetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      storeid:'',
      store:'',
      cats:'',
      cat:'',
      catid:'',
      currentuserid:'',
      currentuser:'',
      mystore:'',
      isfollow:false,

  },

  follow:function(){
    console.log(this.data.store)

    wx.cloud.init();
    const db = wx.cloud.database();
  
    var mystore = this.data.currentuser.mystore
    mystore.push(this.data.store._id)
    console.log(this.data.currentuser)
    db.collection('user').where({
      _id:this.data.currentuserid
    }).update({
      data:{
        mystore:mystore,
        
      }
    }).then(res=>{
      console.log(res)
      let pages = getCurrentPages();
      let prepage = pages[pages.length-2];
      prepage.loadmystore();
    })
    var prehot = this.data.store.hot
    db.collection('store').where({
      _id:this.data.store._id
    }).update({
      data:{
        hot:prehot+1,
        
      }
    }).then(res=>{
      console.log(res)
      
    })


    

    wx.showToast({
      title: '关注成功',
    })


    db.collection('store').where({
      _id:this.data.store._id,
    }).get({
      success:res=>{
        this.setData({
          store:res.data[0],
          isfollow:true
        })  
       

        console.log(this.data.isfollow)
        
      }
    })
    

  },

  catdetail:function(e){
   
    this.setData({
      cat:e.currentTarget.dataset.cat
    })
    console.log(this.data.cat)
    wx.navigateTo({
      url: '/pages/catdetail/catdetail?cat='+JSON.stringify(this.data.cat),
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      store:JSON.parse(options.store)
    })


    var app = getApp()
    this.setData({
      currentuserid:app.data.userid
    })
    
    
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('user').where({
      _id:this.data.currentuserid,
    }).get({
      success:res=>{
        this.setData({
          currentuser:res.data[0],
          mystore:res.data[0].mystore
        })  
        var myfollow  = this.data.mystore;
        console.log(myfollow)
        myfollow.forEach((v,i)=>{
          if(v==this.data.store._id){
            this.setData({
              isfollow:true
            })
          }
        })

        console.log(this.data.isfollow)
        
      }
    })
    
    var _ = db.command;
    db.collection('cat').where({ 
      _id:_.in(this.data.store.mycat)
    }).get({
      success:res=>{
        this.setData({
          cats:res.data,

        })
        console.log(this.data.cats)
      }
      
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})