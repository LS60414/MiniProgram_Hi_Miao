Page({
  menuTap:function(e){
    menuTapCurrent:'0';
    var current=e.currentTarget.dataset.current;//获取到绑定的数据
    //改变menuTapCurrent的值为当前选中的menu所绑定的数据
    this.setData({
    menuTapCurrent:current
    });
    },
    
  /**
   * 页面的初始数据
   */
  data: {
    currentuser:'',
    userid:0,
    index:0,
    catid:'',
    menuTapCurrent:'0',
    myadd:'',
    tabs:[// 是否选中
        {id:0,value:"我的",isActive:true
        },{id:1, value:"推荐",isActive:false
        },{id:2,value:"排行榜",isActive:false

        }],
        // 放猫的编号
      my:[],
      recommend:[2,11,3,4,6,10,5,13],
      rank:[],
      catclass:'',
      store:'',
      cat:'',
      cats:'',
      inputvalue:'',
      searchresult:'',
    
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
 

  
  handleItemTap :function(e){
    const {index} = e.currentTarget.dataset;
    let {tabs} = this.data;//要获取所有的data
    tabs.forEach((v,i)=>i===index? v.isActive=true:v.isActive=false);
    this.setData({
      //丢回去渲染的作用
      tabs

    })
   
    // 加载排行榜
    if(index==2){
      const{cats} = this.data;
      var newrank = [];
      //  const得是原来就有的
      var lenth = cats.length;
     for(var i=0;i<lenth;i++){
       newrank[i]=i;
     } 
     console.log(newrank)
    //  冒泡排序
      for (var i = 0; i < lenth-1 ; i++) {
        for (var j = 0; j < lenth - 1 - i; j++) {
          var hot1 = this.data.cats[newrank[j]].hot;
          var hot2 = this.data.cats[newrank[j+1]].hot;
            if (hot1 <= hot2) {        // 相邻元素两两对比
                var temp = newrank[j+1];        // 元素交换
                newrank[j+1] = newrank[j];
                newrank[j] = temp;
            }
        }
        
    }
      this.setData({
        rank:newrank
      })
      console.log(this.data.rank)
    }
  },
 btncat:function(e){
  console.log(e.currentTarget.dataset)
  var cat= e.currentTarget.dataset.cat;
 
  this.setData({
    cat:cat
  })
  console.log(cat)
  wx.navigateTo({
    url: "/pages/catdetail/catdetail?cat="+JSON.stringify(cat),
  })
 },

 btncat2:function(e){
  var cat = e.currentTarget.dataset.cat;
  console.log(e.currentTarget.dataset.cat)
  this.setData({
    cat:cat
  })
  
  wx.navigateTo({
    url: "/pages/catdetail/catdetail?cat="+JSON.stringify(cat),
  })
 },




input(e){
  this.setData({
    inputvalue:e.detail.value,

  })
  
},
search :function(e){
  console.log(this.data.inputvalue)
  wx.cloud.init();
    const db = wx.cloud.database();
    const _ = db.command
    db.collection('cat').where(_.or([
    {
      name:db.RegExp({
          regexp:'.*'+this.data.inputvalue+'.*',
          options:'i',
      })
    },{
      store:db.RegExp({
        regexp:'.*'+this.data.inputvalue+'.*',
        options:'i',
    })
    },{
      class:db.RegExp({
        regexp:'.*'+this.data.inputvalue+'.*',
        options:'i',
    })
    }])).field({
      class:true,
      name:true,
      store:true,
      _id:true,
      img:true,
      age:true,
      hot:true,
      imgs:true
    }).get({
        success:res=>{
        this.setData({
          searchresult:res.data
        })
        console.log(this.data.searchresult)
        wx.navigateTo({
          url: '/pages/searchcat/searchcat?searchcats='+JSON.stringify(this.data.searchresult),
        })
    }})

  

 


},




  onLoad: function(options) {
    var app = getApp()
    this.setData({
      userid:app.data.userid
    })
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('user').where({
      _id:this.data.userid
    }).get({
      success:res=>{
        this.setData({
          currentuser:res.data[0]
        })
        console.log(this.data.currentuser)
         // #加载了以后就一直要用的放onload
         const _ = db.command;
         db.collection('cat').where({ 
           _id:_.in(this.data.currentuser.mycat)
         }).get({
           success:res=>{
             this.setData({
               my:res.data
             })
           console.log(this.data.my)
           
         }
       })
      }
    })
    db.collection('cat').get({
      success:res=>{
        this.setData({
          cats:res.data
        })
        console.log(this.data.cats)
      }
    })
    
   
  },
    
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
 
  },
 
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function(e) {
  
  },
 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
 
  },
 
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
 
  },
 
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
 
  },
 
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
 
  },
 
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
 
  }
})