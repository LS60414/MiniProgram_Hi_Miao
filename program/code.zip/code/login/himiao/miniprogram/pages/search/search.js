// pages/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentuser:'',
    currentuserid:'',
    show1:false,//控制下拉列表的显示隐藏，false隐藏、true显示
    show2:false,
    show3:false,
    show4:false,
    topclass:'',
    class:'',//下拉列表的数据
    // city:['杭州','上海','北京','广州'],//下拉列表的数据,真实数据换成city里的name
    // age:['10-15','15-25','25-30','30-35','35-40','40以上'],//下拉列表的数据
    // sex:['男','女'],//下拉列表的数据
    index:0,//选择的下拉列表下标
    classid:0,
    cityid:0,
    ageid:0,
    sexid:0,
    
    friends:'',
  },
  
 
    searchfriend(){
      let {friends}=this.data;
      var currentuser = this.data.currentuser;
      var score=[];
      var usersindex = [];

     console.log(this.data.friends)
      friends.forEach((v,i) => {
        var sum=0;
        if(v.catclass==currentuser.catclass){
          sum+=1
        }
        if(v.city==currentuser.city){
          sum+=2
        }
        if(Math.abs(v.age-currentuser.age)<10){
          sum+=2-0.1*Math.abs(v.age-currentuser.age)
        }
        if(v.sex==currentuser.sex){
          sum+=1
        }
        score.push(sum);
        usersindex.push(i)
      });
      console.log(score)
      console.log(usersindex)
      var lenth = usersindex.length;
      // 反正就是找得分最高的啊
      for (var i = 0; i < lenth-1 ; i++) {
        for (var j = 0; j < lenth - 1 - i; j++) {
          var hot1 = score[usersindex[j]];
          var hot2 = score[usersindex[j+1]];
            if (hot1 <= hot2) {        // 相邻元素两两对比
                var temp = usersindex[j+1];        // 元素交换
                usersindex[j+1] = usersindex[j];
                usersindex[j] = temp;
            }
        }
      }
      var friendsrank = []
      var scorerank = []
      usersindex.forEach((v,i)=>{
        if(friends[v]._id!=currentuser._id){
          friendsrank.push(friends[v])
          scorerank.push(score[v])
        }
        
      })
      console.log(usersindex);
      console.log(scorerank);
      wx.navigateTo({
      
        url: '/pages/searchresult/searchresult?friends='+JSON.stringify(friendsrank)+'&score='+JSON.stringify(scorerank),
      })
    },
 

  /**
   * 生命周期函数--监听页面加载
   */
 
  
  onLoad: function (options) {
    var app = getApp()
    this.setData({
      currentuserid:app.data.userid
    })
    console.log(this.data.currentuserid)
    wx.cloud.init()
    const db = wx.cloud.database();
  
    db.collection('user').where({
        _id:this.data.currentuserid
      }).get({
      success : res=>{
      this.setData({
          currentuser:res.data[0]
      })
      
    }
  })
  db.collection('user').get({
  success : res=>{
  this.setData({
      friends:res.data
  })
  
console.log(this.data.friends)
}
})
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})