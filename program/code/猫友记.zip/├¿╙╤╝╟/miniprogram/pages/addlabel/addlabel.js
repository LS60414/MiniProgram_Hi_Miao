// pages/addlabel/addlabel.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentuserid:'',
    show:false,
    labels:'',
    label:'',
    prelabel:'', 
    mylabel:''
  },
  btnlabels:function(){
    this.setData({
      show:!this.data.show
    })
},
btnlabel:function(e){
  const{label} = e.currentTarget.dataset;
  this.setData({
    label,
    show:!this.data.show
  })
},
addlabel:function(){
  const{prelabel}=this.data;
  prelabel.push(this.data.label._id)
  wx.cloud.init();
  const db = wx.cloud.database();
  db.collection('user').where({
    _id:this.data.currentuserid
  }).update({
    data:{
      label:this.data.prelabel
    } 
  }).then(res=>{
      
       
    wx.showToast({
      title: '添加成功',
    })
    let pages = getCurrentPages();
    let prepage = pages[pages.length-1];
    prepage.loadlabels();
  })

  //执行顺序竟然是先外后内的
  wx.switchTab({
      url: '/pages/mine/mine',
    })

},



addmylabel(e){
  this.setData({
    mylabel:e.detail.value,

  })
  
},
submit :function(e){
  wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('label').add({
      data:{
        label:this.data.mylabel
      }
    }).then(res=>{
      const{prelabel} = this.data;
      console.log(res)
      console.log(prelabel)
      prelabel.push(res._id)
      db.collection('user').where({
        _id:this.data.currentuserid
      }).update({
        data:{
          label:this.data.prelabel
        } 
      }).then(res=>{
      
       
        wx.showToast({
          title: '添加成功',
        })
        let pages = getCurrentPages();
        let prepage = pages[pages.length-1];
        prepage.loadlabels();
      })
    })

    

  

  wx.switchTab({
      url: '/pages/mine/mine',
    })


},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('label').get({
      success:res=>{
        this.setData({
          labels:res.data,
          label:res.data[0]
        })
      }
    })
    var app = getApp()
    this.setData({
      currentuserid:app.data.userid
    })
    console.log(this.data.currentuserid)
    db.collection('user').where({
      _id:this.data.currentuserid
    }).get({
      success:res=>{
        this.setData({
          prelabel:res.data[0].label
        })
        console.log(this.data.prelabel)
      }
    })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})