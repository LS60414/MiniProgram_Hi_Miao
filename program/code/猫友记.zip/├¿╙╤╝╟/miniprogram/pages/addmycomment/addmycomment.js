Page({
    /*页面的初始数据*/
    data: {
      userid:'',
      user:'',
      becommented:'',
      newcomment:'',
      lastid:'',
    },
  
    inputcom(e){
      console.log(e)
      this.setData({
        newcomment:e.detail.value
      })
      
    },
  
  
    submit :function(e){
      console.log(this.data.newcomment)
      wx.cloud.init();
      const db = wx.cloud.database();
     
  
      console.log(this.data.user)
  
      db.collection('comment').add({
        data:{
          id2 :this.data.becommented._id,
          username: this.data.user.name,
         userimg:this.data.user.img,
          userid:this.data.user._id,
          comment:this.data.newcomment,
          // id:this.data.lastid+1,
          catid :this.data.becommented.catid,
          issecletd :false,
          score:0,
        }
      })
  
      wx.showToast({
        title: '添加成功',
      })
      let pages = getCurrentPages();
      let prepage = pages[pages.length-2];
      prepage.loadallcomments();
  
      wx.navigateBack({
        delta: 0,
      })
    },
  
    /*生命周期函数--监听页面加载*/
    onLoad: function (options) {
      this.setData({
        becommented:JSON.parse(options.comment)
      })
      console.log(this.data.becommented)
  
      var app = getApp()
      this.setData({
        userid:app.data.userid
      })
      console.log(this.data.userid)
      wx.cloud.init();
      const db = wx.cloud.database();
      db.collection('user').where({
        _id:this.data.userid
      }).get({
        success:res=>{
          console.log(res.data)
          this.setData({
            user:res.data[0]
          })
          console.log(this.data.user)
        }
      })
      // this.loadprecommentid();
  
     
    },
  
  })
  
  