// pages/login3/login3.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        defaultAvatar:  "cloud://cloud1-7gavs1qz9e9c4e96.636c-cloud1-7gavs1qz9e9c4e96-1308660109/捕获.JPG",
        hasUserInfo: false,
        userInfo:'',
        name:'',
        head:'',
        openid:'',
        gender:''
    },
    getUserProfile(){
      var that = this
        wx.cloud.init()
        wx.getUserProfile({
            desc: '该信息仅用于展示在个人中心',
            
            success: (res) => {
                var gender = "保密"
                gender = res.userInfo.gender==0? '女':'男'
                console.log(res.userInfo)
                this.setData({
                    hasUserInfo:true,
                    userInfo:res.userInfo,
                    name:res.userInfo.nickName,
                    head:res.userInfo.avatarUrl,
                    gender:gender
                })
                // app.setUserInfo(res.userInfo)
                wx.setStorageSync('userInfo', res.userInfo);
                let userInfo= res.userInfo
                console.log(userInfo)
                this.setData({
                  user: res.userInfo
                })
                console.log(userInfo)
                //获取openId（需要code来换取）这是用户的唯一标识符
                // 获取code值
                wx.login({
                  //成功放回
                  success:(res)=>{
                    console.log(res);
                    let code=res.code
  
                    wx.cloud.callFunction({
                      name:'getUserProfile',
                      success: function(res) {
                        console.log(res) 
                        that.setData({
                            openid: res.result.openid
                        })
                        console.log(res.result.openid) 
                        console.log(that.data.openid) 
                        var app = getApp()
                        app.data.userid = res.result.openid
                        console.log(app.data.userid)
                        that.checkuser()
                    },
                    fail: console.error
                      
                    })
  
                    // 通过code换取openId
                    // wx.request({
                    //   url: `https://api.weixin.qq.com/sns/jscode2session?appid=wxb35dbe81feb91906&secret=0e503cc719ae138108a5135f8d43ef06&js_code=${code}&grant_type=authorization_code`,
                    //   success:(res)=>{
                    //     userInfo.openid=res.data.openid
                    //     wx.setStorageSync('userInfo', res.userInfo);
                    //     console.log(userInfo.openid);
                    //     console.log(res.data);
                    //     this.setData({
                    //         openid:res.data.openid
                    //     })
                    //     console.log(this.data.openid)
                    //     console.log(this.data.head)
                    //     console.log(this.data.name)
                    //     this.checkuser()
                    //   }
                    // })
                  }
                })
        
  
               
            },
          })
    },
  
  
    checkuser:function(){
        const app = getApp()
        wx.cloud.init();
        const db = wx.cloud.database();
        db.collection('user').where({
          _openid:this.data.openid
        }).get({
            success:res=>{
                if(res.data.length>0){
                    app.data.userid = res.data[0]._id
                }else{
                    db.collection('user').add({
                        data:{
                            _openid:this.data.openid,
                            name:this.data.name,
                            score:0,
                            label:[],
                            mycat:[],
                            mystore:[],
                            sex:this.data.gender,
                            city:'杭州',
                            age:18,
                            img:this.data.head
                        }
                      }).then(res=>{
                        console.log(res)
                        app.data.userid = res._id
                        
                      })
                     
                }
                //执行顺序竟然是先外后内的
                wx.switchTab({
                    url: '/pages/index/index',
                })
               
            }
  
        })
    },
  
  
    signIn:function(){
        //先获取头像和名字然后获取openid
        this.getUserProfile();
       
    },
  
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.getUserProfile()
  
    },
  
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.getUserProfile()
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
  
    }
  })