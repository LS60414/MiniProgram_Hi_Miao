Page({
    
  data: {
    index :0,
    my:'',
    recommend:[0,1,2,4,6,7],
    hot:[0,4,2,3,1,5],
    tabs:[// 是否选中
      {id:0,value:"关注",isActive:true
      },{id:1, value:"推荐",isActive:false
      },{id:2,value:"热门",isActive:false

      }],
      store:'',
      stores:'',
      currentuser:'',
      userid:'',
      inputvalue:'',
      searchresult:'',
   
  },
  handleItemTap :function(e){
    const {index} = e.currentTarget.dataset;
    let {tabs} = this.data;//要获取所有的data
    console.log({tabs})
    tabs.forEach((v,i)=>i===index? v.isActive=true:v.isActive=false);
    this.setData({
      //丢回去渲染的作用
      tabs

    })
  },
  btnstore:function(e){
    var store= e.currentTarget.dataset.store;
    console.log(e.currentTarget.dataset.store)
    this.setData({
      store:store
    })
    wx.navigateTo({
      url: "/pages/storedetail/storedetail?store="+JSON.stringify(store),
    })
   },

   loadmystore:function( ){
    var app = getApp()
    this.setData({
      userid:app.data.userid
    })
    wx.cloud.init();
    const db = wx.cloud.database();
    db.collection('user').where({
      _id:this.data.userid
    }).get({
      success:res=>{
        this.setData({
          currentuser:res.data[0]
        })
        console.log(this.data.currentuser)
         // #加载了以后就一直要用的放onload

         const _ = db.command;
         db.collection('store').where({ 
           _id:_.in(this.data.currentuser.mystore)
         }).get({
           success:res=>{
             this.setData({
               my:res.data
             })
           console.log(this.data.my)
           
         }
       })
      }
    })

   

   },

  



   input(e){
    this.setData({
      inputvalue:e.detail.value,
  
    })
    
  },
  search :function(e){
    console.log(this.data.inputvalue)
    wx.cloud.init();
      const db = wx.cloud.database();
      const _ = db.command
      db.collection('store').where(_.or([
      {
        storename:db.RegExp({
            regexp:'.*'+this.data.inputvalue+'.*',
            options:'i',
        })
      },{
        summary:db.RegExp({
          regexp:'.*'+this.data.inputvalue+'.*',
          options:'i',
      })
      },{
        city:db.RegExp({
          regexp:'.*'+this.data.inputvalue+'.*',
          options:'i',
      })
      }])).field({
        storename:true,
        city:true,
        summary:true,
        _id:true,
        img:true,
        address:true,
        phone:true,
        mycat:true,
        imgs:true,
        isbusy:true
      }).get({
          success:res=>{
          this.setData({
            searchresult:res.data
          })
          console.log(this.data.searchresult)
          wx.navigateTo({
            url: '/pages/searchstore/searchstore?searchstores='+JSON.stringify(this.data.searchresult),
          })
      }})
  
    
  
   
  
  
  },
  
  
  


  onLoad: function (e) {
    this.loadmystore();

    wx.cloud.init();
    const db = wx.cloud.database();
    
    db.collection('store').get({
      success : res=>{
      this.setData({
          stores:res.data
      })
    }
  })
  },

  
})